package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;
import com.mie.util.*;


public class MemberCreation {
	
	static Connection currentCon = null;
	static ResultSet rs=null;
	static ResultSet idNum = null;
	
	public static Member signup(Member member) {
		Statement stmt = null;

		String email = member.getEmail();
		String password = member.getPassword();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		 /* Prepare a query that searches the members table in the database
		 * with the given username and password.
		 */
		String searchQuery = "SELECT * FROM Members WHERE Email='"
				+ email + "'";

		try {
			// connect to DB
			currentCon = DbUtil.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/* If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			
			if (more) {
				// this is good, write to file
				member.setValid(true);
			}
			/*If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to
			 * the Member object.
			 */
			else if (!more) {
				member.setValid(false);
			}
		}
		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/* Return the Member object.
		 */
		return member;
	}
	public static Member signupWrite(Member member) {
		Statement stmt = null;

		String email = member.getEmail();
		String password = member.getPassword();

		 /* Prepare a query that searches the members table in the database
		 * with the given username and password.
		 */
		String countPeople = "SELECT count(*) FROM Members";
		
		currentCon = DbUtil.getConnection();
		stmt = currentCon.createStatement();
		idNum = stmt.executeQuery(countPeople);
		
		
		String searchQuery = "INSERT INTO Members (MembersID, FirstName, LastName, Username, email, Password, LastLogin) values ("+ idNum +", "+ member.getFirstName()
				+", "+ member.getLastName() +", "+ member.getUsername() +", "+ member.getEmail()+", "+member.getPassword()+", "+;

		currentCon = DbUtil.getConnection();
		stmt = currentCon.createStatement();
		rs = stmt.executeQuery(searchQuery);
		boolean more = rs.next();
		
	}
}
